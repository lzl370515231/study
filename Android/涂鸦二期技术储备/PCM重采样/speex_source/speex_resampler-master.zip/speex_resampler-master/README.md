# speex_resampler
Speex audio re-sampler sample project.

This demo project resample 48K audio to 44.1K sample rate using speex library module.
There is a python script to record audio from microphone at 48K sample rate.
