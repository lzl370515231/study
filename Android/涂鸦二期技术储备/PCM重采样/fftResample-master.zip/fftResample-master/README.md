# fftResample
a simple wave resampling by fft example.

deps:
hsfft:  https://github.com/rafat/hsfft